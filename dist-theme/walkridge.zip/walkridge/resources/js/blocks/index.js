/**
 * Walkridge Gutenberg blocks — editor registration.
 *
 * All blocks are server-side rendered (save returns null).
 * The inspector sidebar drives attribute edits; ServerSideRender
 * shows a live PHP-rendered preview in the editor canvas.
 *
 * Advanced controls per block type:
 *  – URLInput for all URL fields (link picker + validation)
 *  – MediaUpload / MediaUploadCheck for custom image selection
 *  – BlockControls toolbar for heading-level + text-alignment
 *  – RangeControl, ToggleControl, SelectControl for display options
 */

import { registerBlockType, getCategories, setCategories, registerBlockCollection } from '@wordpress/blocks';
import {
  InspectorControls,
  BlockControls,
  MediaUpload,
  MediaUploadCheck,
  URLInput,
  HeadingLevelDropdown,
  AlignmentControl,
  useBlockProps,
} from '@wordpress/block-editor';
import {
  PanelBody,
  TextControl,
  TextareaControl,
  ToggleControl,
  RangeControl,
  SelectControl,
  Spinner,
  Button,
  ToolbarGroup,
  Notice,
} from '@wordpress/components';
import { createElement as el, Fragment } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import ServerSideRender from '@wordpress/server-side-render';

const walkridgeIcon = el(
  'svg',
  { viewBox: '0 0 24 24', xmlns: 'http://www.w3.org/2000/svg', width: 24, height: 24 },
  el('circle', { cx: 12, cy: 12, r: 10, fill: 'none', stroke: 'currentColor', strokeWidth: 1.5 }),
  el('path', { d: 'M12 4l2.2 8L12 20l-2.2-8z', fill: 'currentColor' }),
  el('path', { d: 'M4 12l8-2.2L20 12l-8 2.2z', fill: 'currentColor', opacity: 0.4 }),
);

if (!getCategories().find((c) => c.slug === 'walkridge')) {
  setCategories([
    { slug: 'walkridge', title: 'Walkridge', icon: walkridgeIcon },
    ...getCategories(),
  ]);
} else {
  setCategories(
    getCategories().map((c) => (c.slug === 'walkridge' ? { ...c, icon: walkridgeIcon, title: 'Walkridge' } : c)),
  );
}

if (typeof registerBlockCollection === 'function') {
  registerBlockCollection('walkridge', {
    title: __('Walkridge', 'walkridge'),
    icon: walkridgeIcon,
  });
}

const cfg = window.WALKRIDGE_BLOCKS || {};

// ── Shared SSR wrapper ────────────────────────────────────────────
function SsrEdit({ name, attributes, sidebar, toolbar }) {
  const blockProps = useBlockProps({ className: 'wr-block-ssr' });
  return el(
    Fragment,
    null,
    toolbar ? el(BlockControls, null, toolbar()) : null,
    el(InspectorControls, null, sidebar()),
    el(
      'div',
      blockProps,
      el(ServerSideRender, {
        block: name,
        attributes,
        LoadingResponsePlaceholder: () =>
          el(
            'div',
            { style: { padding: 32, textAlign: 'center', opacity: 0.5 } },
            el(Spinner),
            el('p', { style: { marginTop: 8, fontSize: 12 } }, __('Rendering preview…', 'walkridge')),
          ),
        ErrorResponsePlaceholder: ({ response }) =>
          el(
            Notice,
            { status: 'warning', isDismissible: false, style: { margin: 8 } },
            __('Preview error — check block attributes or save the page to refresh.', 'walkridge'),
          ),
      }),
    ),
  );
}

// ── Reusable helpers ──────────────────────────────────────────────

/** Plain text / textarea panel. */
function textPanel(title, fields, attrs, set, initialOpen = true) {
  return el(
    PanelBody,
    { title, initialOpen },
    ...fields.map(([key, label, multiline]) =>
      el(multiline ? TextareaControl : TextControl, {
        key,
        label,
        value: attrs[key] || '',
        onChange: (v) => set({ [key]: v }),
      }),
    ),
  );
}

/** URL picker using URLInput (shows site search + typing). */
function urlField(label, key, attrs, set) {
  return el(
    'div',
    { key, style: { marginBottom: 16 } },
    el(
      'label',
      {
        style: {
          display: 'block',
          marginBottom: 4,
          fontSize: 11,
          fontWeight: 500,
          textTransform: 'uppercase',
          color: 'var(--wp-components-color-accent,#007cba)',
        },
      },
      label,
    ),
    el(URLInput, {
      value: attrs[key] || '',
      onChange: (v) => set({ [key]: v }),
      isFullWidth: true,
      hasBorder: true,
    }),
  );
}

/** Media upload button that sets a URL attribute. */
function mediaUploadField(label, urlKey, attrs, set) {
  const hasImage = !!(attrs[urlKey] || '');
  return el(
    PanelBody,
    { title: label, initialOpen: false },
    el(
      MediaUploadCheck,
      null,
      el(MediaUpload, {
        onSelect: (media) => set({ [urlKey]: media.url }),
        allowedTypes: ['image'],
        render: ({ open }) =>
          el(
            Fragment,
            null,
            hasImage &&
              el('img', {
                src: attrs[urlKey],
                alt: '',
                style: {
                  width: '100%',
                  height: 120,
                  objectFit: 'cover',
                  borderRadius: 2,
                  marginBottom: 8,
                },
              }),
            el(
              Button,
              {
                onClick: open,
                variant: hasImage ? 'secondary' : 'primary',
                style: { width: '100%', justifyContent: 'center' },
              },
              hasImage ? __('Replace image', 'walkridge') : __('Choose image', 'walkridge'),
            ),
            hasImage &&
              el(
                Button,
                {
                  onClick: () => set({ [urlKey]: '' }),
                  variant: 'tertiary',
                  isDestructive: true,
                  style: { marginTop: 4, width: '100%', justifyContent: 'center' },
                },
                __('Remove image', 'walkridge'),
              ),
          ),
      }),
    ),
  );
}

// Heading levels available to the section-heading block
const HEADING_LEVELS = [2, 3, 4, 5];

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/home-hero
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/home-hero', {
  title: __('Home Hero', 'walkridge'),
  category: 'walkridge',
  icon: 'cover-image',
  supports: { html: false, multiple: false },
  attributes: {
    eyebrow: { type: 'string', default: '' },
    title: { type: 'string', default: 'Walk the ground where <em>history turned.</em>' },
    text: { type: 'string', default: '' },
    primaryLabel: { type: 'string', default: '' },
    primaryUrl: { type: 'string', default: '' },
    secondaryLabel: { type: 'string', default: 'See All Tours' },
    secondaryUrl: { type: 'string', default: '' },
    imageKey: { type: 'string', default: 'cannon' },
    imageUrl: { type: 'string', default: '' },
    stats: { type: 'string', default: '' },
    marquee: { type: 'string', default: '' },
    leftPathTitle: { type: 'string', default: '' },
    leftPathText: { type: 'string', default: '' },
    rightPathTitle: { type: 'string', default: '' },
    rightPathText: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/home-hero',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Hero copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow', 'walkridge'), false],
              ['title', __('Title (HTML: em/strong)', 'walkridge'), false],
              ['text', __('Lede paragraph', 'walkridge'), true],
              ['primaryLabel', __('Primary button label', 'walkridge'), false],
              ['secondaryLabel', __('Secondary button label', 'walkridge'), false],
              ['leftPathTitle', __('Left path title', 'walkridge'), false],
              ['leftPathText', __('Left path text', 'walkridge'), true],
              ['rightPathTitle', __('Right path title', 'walkridge'), false],
              ['rightPathText', __('Right path text', 'walkridge'), true],
              ['stats', __('Stats (one per line: Value | Label)', 'walkridge'), true],
              ['marquee', __('Marquee places (pipe or newline separated)', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Button URLs', 'walkridge'), initialOpen: false },
            urlField(__('Primary button URL', 'walkridge'), 'primaryUrl', a, s),
            urlField(__('Secondary button URL', 'walkridge'), 'secondaryUrl', a, s),
          ),
          el(
            PanelBody,
            { title: __('Background image', 'walkridge'), initialOpen: false },
            el(SelectControl, {
              label: __('Preset image', 'walkridge'),
              value: a.imageKey || 'cannon',
              options: [
                { label: __('Cannon (default)', 'walkridge'), value: 'cannon' },
                { label: __('Wentz farmstead', 'walkridge'), value: 'wentz' },
                { label: __('Downtown Gettysburg', 'walkridge'), value: 'downtown' },
              ],
              onChange: (v) => s({ imageKey: v }),
              help: __('Overridden by a custom image upload below.', 'walkridge'),
            }),
          ),
          mediaUploadField(__('Custom background image', 'walkridge'), 'imageUrl', a, s),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/page-intro
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/page-intro', {
  title: __('Page Intro', 'walkridge'),
  category: 'walkridge',
  icon: 'heading',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: '' },
    heading: { type: 'string', default: '' },
    intro: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/page-intro',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          el(
            Notice,
            {
              status: 'info',
              isDismissible: false,
              style: { margin: '8px 16px' },
            },
            __(
              'This copy lives on the block. Empty fields use the theme’s demo text for this page slug — not custom fields.',
              'walkridge',
            ),
          ),
          textPanel(
            __('Page intro', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['intro', __('Intro paragraph', 'walkridge'), true],
            ],
            a,
            s,
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/info-strip
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/info-strip', {
  title: __('Info Strip', 'walkridge'),
  category: 'walkridge',
  icon: 'info',
  supports: { html: false },
  attributes: {
    showPhone: { type: 'boolean', default: true },
    showAddress: { type: 'boolean', default: true },
    showHours: { type: 'boolean', default: true },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/info-strip',
      attributes: a,
      sidebar: () =>
        el(
          PanelBody,
          { title: __('Visible items', 'walkridge'), initialOpen: true },
          el(ToggleControl, {
            label: __('Phone number', 'walkridge'),
            checked: !!a.showPhone,
            onChange: (v) => s({ showPhone: v }),
          }),
          el(ToggleControl, {
            label: __('Address', 'walkridge'),
            checked: !!a.showAddress,
            onChange: (v) => s({ showAddress: v }),
          }),
          el(ToggleControl, {
            label: __('Hours', 'walkridge'),
            checked: !!a.showHours,
            onChange: (v) => s({ showHours: v }),
          }),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/section-heading
// Advanced: heading level toolbar + text alignment toolbar
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/section-heading', {
  title: __('Section Heading', 'walkridge'),
  category: 'walkridge',
  icon: 'editor-textcolor',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: '' },
    heading: { type: 'string', default: '' },
    text: { type: 'string', default: '' },
    anchor: { type: 'string', default: '' },
    alt: { type: 'boolean', default: false },
    headingLevel: { type: 'number', default: 2 },
    textAlign: { type: 'string', default: 'center' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/section-heading',
      attributes: a,
      toolbar: () =>
        el(
          Fragment,
          null,
          // WP core heading-level picker — matches the core/heading block UX
          el(
            ToolbarGroup,
            null,
            el(HeadingLevelDropdown, {
              value: a.headingLevel || 2,
              options: HEADING_LEVELS,
              onChange: (v) => s({ headingLevel: v }),
            }),
          ),
          // WP core text-alignment control
          el(
            ToolbarGroup,
            null,
            el(AlignmentControl, {
              value: a.textAlign || 'center',
              onChange: (v) => s({ textAlign: v || 'center' }),
              alignmentControls: [
                { align: 'left', title: __('Align left', 'walkridge') },
                { align: 'center', title: __('Align center', 'walkridge') },
                { align: 'right', title: __('Align right', 'walkridge') },
              ],
            }),
          ),
        ),
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Content', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading (HTML: em/strong)', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
              ['anchor', __('Anchor ID (for #links)', 'walkridge'), false],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Style', 'walkridge'), initialOpen: false },
            el(ToggleControl, {
              label: __('Alternate background (dark surface)', 'walkridge'),
              checked: !!a.alt,
              onChange: (v) => s({ alt: v }),
            }),
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/tour-grid
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/tour-grid', {
  title: __('Tour Grid', 'walkridge'),
  category: 'walkridge',
  icon: 'tickets-alt',
  supports: { html: false },
  attributes: {
    limit: { type: 'number', default: 0 },
    showFilters: { type: 'boolean', default: true },
    showCompare: { type: 'boolean', default: true },
    eyebrow: { type: 'string', default: 'Choose Your Tour' },
    heading: { type: 'string', default: 'Ways to walk the field.' },
    text: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/tour-grid',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Section copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Display options', 'walkridge'), initialOpen: true },
            el(RangeControl, {
              label: __('Max tours shown (0 = all)', 'walkridge'),
              value: a.limit || 0,
              min: 0,
              max: 12,
              step: 1,
              marks: true,
              onChange: (v) => s({ limit: v }),
            }),
            el(ToggleControl, {
              label: __('Show category filter bar', 'walkridge'),
              checked: !!a.showFilters,
              onChange: (v) => s({ showFilters: v }),
            }),
            el(ToggleControl, {
              label: __('Show comparison table', 'walkridge'),
              checked: !!a.showCompare,
              onChange: (v) => s({ showCompare: v }),
            }),
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/pathway-cards
// Advanced: URLInput for both card links
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/pathway-cards', {
  title: __('Pathway Cards', 'walkridge'),
  category: 'walkridge',
  icon: 'table-col-after',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'Two Ways In' },
    heading: { type: 'string', default: 'The field by day. The town after dark.' },
    text: { type: 'string', default: '' },
    leftEyebrow: { type: 'string', default: 'Historical' },
    leftTitle: { type: 'string', default: '' },
    leftText: { type: 'string', default: '' },
    leftUrl: { type: 'string', default: '' },
    rightEyebrow: { type: 'string', default: 'After Dark' },
    rightTitle: { type: 'string', default: '' },
    rightText: { type: 'string', default: '' },
    rightUrl: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/pathway-cards',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Section intro', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Left card — Historical', 'walkridge'), initialOpen: true },
            el(TextControl, {
              label: __('Eyebrow', 'walkridge'),
              value: a.leftEyebrow || '',
              onChange: (v) => s({ leftEyebrow: v }),
            }),
            el(TextControl, {
              label: __('Title', 'walkridge'),
              value: a.leftTitle || '',
              onChange: (v) => s({ leftTitle: v }),
            }),
            el(TextareaControl, {
              label: __('Text', 'walkridge'),
              value: a.leftText || '',
              onChange: (v) => s({ leftText: v }),
            }),
            urlField(__('Card link URL', 'walkridge'), 'leftUrl', a, s),
          ),
          el(
            PanelBody,
            { title: __('Right card — After Dark', 'walkridge'), initialOpen: true },
            el(TextControl, {
              label: __('Eyebrow', 'walkridge'),
              value: a.rightEyebrow || '',
              onChange: (v) => s({ rightEyebrow: v }),
            }),
            el(TextControl, {
              label: __('Title', 'walkridge'),
              value: a.rightTitle || '',
              onChange: (v) => s({ rightTitle: v }),
            }),
            el(TextareaControl, {
              label: __('Text', 'walkridge'),
              value: a.rightText || '',
              onChange: (v) => s({ rightText: v }),
            }),
            urlField(__('Card link URL', 'walkridge'), 'rightUrl', a, s),
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/about-split
// Advanced: MediaUpload for custom image, URLInput for CTAs,
//           flip-layout toggle
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/about-split', {
  title: __('About Split', 'walkridge'),
  category: 'walkridge',
  icon: 'align-pull-left',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'About Us' },
    heading: { type: 'string', default: 'Guided by licensed historians, not a script.' },
    text: { type: 'string', default: '' },
    primaryLabel: { type: 'string', default: 'Meet Your Guides' },
    primaryUrl: { type: 'string', default: '' },
    secondaryLabel: { type: 'string', default: 'About the Area' },
    secondaryUrl: { type: 'string', default: '' },
    imageKey: { type: 'string', default: 'wentz' },
    imageUrl: { type: 'string', default: '' },
    caption: { type: 'string', default: '' },
    flip: { type: 'boolean', default: false },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/about-split',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Body (HTML allowed)', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Call-to-action buttons', 'walkridge'), initialOpen: false },
            el(TextControl, {
              label: __('Primary button label', 'walkridge'),
              value: a.primaryLabel || '',
              onChange: (v) => s({ primaryLabel: v }),
            }),
            urlField(__('Primary button URL', 'walkridge'), 'primaryUrl', a, s),
            el(TextControl, {
              label: __('Secondary button label', 'walkridge'),
              value: a.secondaryLabel || '',
              onChange: (v) => s({ secondaryLabel: v }),
            }),
            urlField(__('Secondary button URL', 'walkridge'), 'secondaryUrl', a, s),
          ),
          el(
            PanelBody,
            { title: __('Layout', 'walkridge'), initialOpen: false },
            el(ToggleControl, {
              label: __('Flip: image on the left', 'walkridge'),
              checked: !!a.flip,
              onChange: (v) => s({ flip: v }),
              help: __('By default the image is on the right.', 'walkridge'),
            }),
          ),
          el(
            PanelBody,
            { title: __('Image', 'walkridge'), initialOpen: false },
            el(SelectControl, {
              label: __('Preset image', 'walkridge'),
              value: a.imageKey || 'wentz',
              options: [
                { label: __('Wentz farmstead (default)', 'walkridge'), value: 'wentz' },
                { label: __('Cannon', 'walkridge'), value: 'cannon' },
                { label: __('Downtown Gettysburg', 'walkridge'), value: 'downtown' },
              ],
              onChange: (v) => s({ imageKey: v }),
              help: __('Overridden by a custom upload below.', 'walkridge'),
            }),
            el(TextControl, {
              label: __('Caption', 'walkridge'),
              value: a.caption || '',
              onChange: (v) => s({ caption: v }),
            }),
          ),
          mediaUploadField(__('Custom image upload', 'walkridge'), 'imageUrl', a, s),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/book-band
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/book-band', {
  title: __('Book Band', 'walkridge'),
  category: 'walkridge',
  icon: 'cart',
  supports: { html: false },
  attributes: {
    heading: { type: 'string', default: '' },
    text: { type: 'string', default: '' },
    buttonLabel: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/book-band',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          el(
            Notice,
            { status: 'info', isDismissible: false, style: { margin: '8px 16px' } },
            __('This is the page-level booking CTA — distinct from the global site footer.', 'walkridge'),
          ),
          textPanel(
            __('Booking CTA', 'walkridge'),
            [
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
              ['buttonLabel', __('Button label', 'walkridge'), false],
            ],
            a,
            s,
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/cta-band
// Advanced: URLInput for button URL
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/cta-band', {
  title: __('CTA Band', 'walkridge'),
  category: 'walkridge',
  icon: 'megaphone',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: '' },
    heading: { type: 'string', default: '' },
    text: { type: 'string', default: '' },
    buttonLabel: { type: 'string', default: '' },
    buttonUrl: { type: 'string', default: '' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/cta-band',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('CTA copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow label', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
              ['buttonLabel', __('Button label', 'walkridge'), false],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Button URL', 'walkridge'), initialOpen: false },
            urlField(__('Destination URL', 'walkridge'), 'buttonUrl', a, s),
          ),
        ),
    });
  },
  save: () => null,
});

// ─────────────────────────────────────────────────────────────────
// Block: walkridge/custom (generator)
// ─────────────────────────────────────────────────────────────────
registerBlockType('walkridge/custom', {
  title: __('Custom (Generator)', 'walkridge'),
  category: 'walkridge',
  icon: 'admin-generic',
  supports: { html: false },
  attributes: {
    blockId: { type: 'string', default: '' },
    values: { type: 'object', default: {} },
  },
  edit({ attributes: a, setAttributes: s }) {
    const defs = cfg.customBlocks || {};
    const options = [
      { label: __('Select a generated block…', 'walkridge'), value: '' },
      ...Object.keys(defs).map((id) => ({
        label: defs[id].title || id,
        value: id,
      })),
    ];
    const def = defs[a.blockId] || null;
    const values = a.values || {};

    return el(SsrEdit, {
      name: 'walkridge/custom',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          el(
            PanelBody,
            { title: __('Custom block', 'walkridge'), initialOpen: true },
            el(SelectControl, {
              label: __('Definition', 'walkridge'),
              value: a.blockId || '',
              options,
              onChange: (v) => s({ blockId: v, values: {} }),
            }),
            !options.slice(1).length &&
              el(
                'p',
                { className: 'description' },
                __('Create definitions under Tools → Walkridge Blocks.', 'walkridge'),
              ),
          ),
          def &&
            el(
              PanelBody,
              { title: __('Fields', 'walkridge'), initialOpen: true },
              ...(def.fields || []).map((field) => {
                const name = field.name;
                const label = field.label || name;
                const type = field.type || 'text';
                const val = values[name] ?? field.default ?? '';

                if (type === 'toggle') {
                  return el(ToggleControl, {
                    key: name,
                    label,
                    checked: !!val,
                    onChange: (v) => s({ values: { ...values, [name]: v } }),
                  });
                }
                if (type === 'textarea') {
                  return el(TextareaControl, {
                    key: name,
                    label,
                    value: val,
                    onChange: (v) => s({ values: { ...values, [name]: v } }),
                  });
                }
                if (type === 'url') {
                  return el(
                    'div',
                    { key: name, style: { marginBottom: 16 } },
                    el('label', { style: { display: 'block', marginBottom: 4, fontSize: 11 } }, label),
                    el(URLInput, {
                      value: val,
                      onChange: (v) => s({ values: { ...values, [name]: v } }),
                      isFullWidth: true,
                      hasBorder: true,
                    }),
                  );
                }
                return el(TextControl, {
                  key: name,
                  label,
                  value: val,
                  onChange: (v) => s({ values: { ...values, [name]: v } }),
                });
              }),
            ),
        ),
    });
  },
  save: () => null,
});

registerBlockType('walkridge/contact-desk', {
  title: __('Contact Desk', 'walkridge'),
  category: 'walkridge',
  icon: 'email',
  supports: { html: false, multiple: false },
  attributes: {
    eyebrow: { type: 'string', default: 'Reach Us' },
    heading: { type: 'string', default: 'Ticket office & guest services' },
    formEyebrow: { type: 'string', default: 'Send a Message' },
    formHeading: { type: 'string', default: 'Ask us anything' },
    showNap: { type: 'boolean', default: true },
    showForm: { type: 'boolean', default: true },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/contact-desk',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Office copy', 'walkridge'),
            [
              ['eyebrow', __('Office eyebrow', 'walkridge'), false],
              ['heading', __('Office heading', 'walkridge'), false],
              ['formEyebrow', __('Form eyebrow', 'walkridge'), false],
              ['formHeading', __('Form heading', 'walkridge'), false],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Display', 'walkridge'), initialOpen: false },
            el(ToggleControl, {
              label: __('Show phone / email / hours', 'walkridge'),
              checked: a.showNap !== false,
              onChange: (v) => s({ showNap: v }),
            }),
            el(ToggleControl, {
              label: __('Show contact form', 'walkridge'),
              checked: a.showForm !== false,
              onChange: (v) => s({ showForm: v }),
            }),
          ),
        ),
    })
  },
  save: () => null,
})

registerBlockType('walkridge/faq-list', {
  title: __('FAQ List', 'walkridge'),
  category: 'walkridge',
  icon: 'editor-help',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'FAQ' },
    heading: { type: 'string', default: 'Before you book' },
    items: {
      type: 'string',
      default:
        'Do I need a park ticket? | Park entrance rules change by season. Confirm current access before you arrive.\nAre tours ADA-accessible? | The bus loop is the accessible option. Walking tours cover uneven ground.\nCan I cancel? | See the Refund Policy page for the sample store window.',
    },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/faq-list',
      attributes: a,
      sidebar: () =>
        textPanel(
          __('FAQ', 'walkridge'),
          [
            ['eyebrow', __('Eyebrow', 'walkridge'), false],
            ['heading', __('Heading', 'walkridge'), false],
            ['items', __('Items (one per line: Question | Answer)', 'walkridge'), true],
          ],
          a,
          s,
        ),
    })
  },
  save: () => null,
})

registerBlockType('walkridge/guide-roster', {
  title: __('Guide Roster', 'walkridge'),
  category: 'walkridge',
  icon: 'groups',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'The Desk' },
    heading: { type: 'string', default: 'Licensed battlefield guides' },
    items: {
      type: 'string',
      default:
        'Eleanor Voss | Lead walking guide | Twenty years on the field. Primary sources first, then the landscape.\nJames Whitaker | Bus & accessibility | Former interpreter. Keeps the ADA loop paced for questions.\nMaya Trent | Evening lanterns | Civilian streets after dark, letters and the town square.',
    },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/guide-roster',
      attributes: a,
      sidebar: () =>
        textPanel(
          __('Guides', 'walkridge'),
          [
            ['eyebrow', __('Eyebrow', 'walkridge'), false],
            ['heading', __('Heading', 'walkridge'), false],
            ['items', __('Guides (one per line: Name | Role | Bio)', 'walkridge'), true],
          ],
          a,
          s,
        ),
    })
  },
  save: () => null,
})

registerBlockType('walkridge/area-facts', {
  title: __('Area Facts', 'walkridge'),
  category: 'walkridge',
  icon: 'location',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'Find Us' },
    heading: { type: 'string', default: 'Meeting point, parking, and the ground' },
    parking: { type: 'string', default: 'Sample lot on the same block as the concept office. Do not treat this as a real park lot.' },
    meeting: { type: 'string', default: 'Meet at the marked sample office. Walking tours leave from the rail; bus tours load at the curb.' },
    directions: { type: 'string', default: 'From the town square, follow the posted sample street. Fiction address only.' },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/area-facts',
      attributes: a,
      sidebar: () =>
        textPanel(
          __('Area facts', 'walkridge'),
          [
            ['eyebrow', __('Eyebrow', 'walkridge'), false],
            ['heading', __('Heading', 'walkridge'), false],
            ['parking', __('Parking', 'walkridge'), true],
            ['meeting', __('Meeting point', 'walkridge'), true],
            ['directions', __('Directions', 'walkridge'), true],
          ],
          a,
          s,
        ),
    })
  },
  save: () => null,
})

function registerPipedBlock(name, title, icon, extraFields = []) {
  const attributes = {
    eyebrow: { type: 'string', default: '' },
    heading: { type: 'string', default: '' },
    text: { type: 'string', default: '' },
    items: { type: 'string', default: '' },
  }
  extraFields.forEach(([key, , , type]) => {
    attributes[key] = { type: type || 'string', default: type === 'boolean' ? false : '' }
  })
  registerBlockType(name, {
    title,
    category: 'walkridge',
    icon,
    supports: { html: false },
    attributes,
    edit({ attributes: a, setAttributes: s }) {
      const fields = [
        ['eyebrow', __('Eyebrow', 'walkridge'), false],
        ['heading', __('Heading', 'walkridge'), false],
        ['text', __('Supporting text', 'walkridge'), true],
        ...extraFields.map(([key, label, multiline]) => [key, label, !!multiline]),
        ['items', __('Items (one per line, pipe-separated)', 'walkridge'), true],
      ]
      return el(SsrEdit, {
        name,
        attributes: a,
        sidebar: () => textPanel(title, fields, a, s),
      })
    },
    save: () => null,
  })
}

registerPipedBlock('walkridge/timeline', __('Battle Timeline', 'walkridge'), 'backup')
registerPipedBlock('walkridge/card-grid', __('Card Grid', 'walkridge'), 'screenoptions', [
  ['variant', __('Variant (expect or feature)', 'walkridge'), false],
])
registerPipedBlock('walkridge/reviews', __('Guest Reviews', 'walkridge'), 'star-filled')
registerPipedBlock('walkridge/journal-cards', __('Journal Cards', 'walkridge'), 'book-alt')
registerPipedBlock('walkridge/town-grid', __('Town Grid', 'walkridge'), 'location-alt')
registerBlockType('walkridge/copy-section', {
  title: __('Copy Section', 'walkridge'),
  category: 'walkridge',
  icon: 'media-text',
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: '' },
    heading: { type: 'string', default: '' },
    text: { type: 'string', default: '' },
    alt: { type: 'boolean', default: false },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/copy-section',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Body HTML', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Style', 'walkridge'), initialOpen: false },
            el(ToggleControl, {
              label: __('Alternate background', 'walkridge'),
              checked: !!a.alt,
              onChange: (v) => s({ alt: v }),
            }),
          ),
        ),
    })
  },
  save: () => null,
})

registerBlockType('walkridge/refund-policy', {
  title: __('Refund Policy', 'walkridge'),
  category: 'walkridge',
  icon: 'clipboard',
  supports: { html: false, multiple: false },
  attributes: {
    effectiveDate: { type: 'string', default: 'September 2, 2026' },
    storeName: { type: 'string', default: '' },
    storeUrl: { type: 'string', default: '' },
    contactEmail: { type: 'string', default: '' },
    refundWindowDays: { type: 'number', default: 30 },
    resolutionDays: { type: 'number', default: 7 },
    duplicateDays: { type: 'number', default: 7 },
    responseDays: { type: 'number', default: 2 },
    paymentDaysMin: { type: 'number', default: 5 },
    paymentDaysMax: { type: 'number', default: 10 },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/refund-policy',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          el(
            Notice,
            { status: 'info', isDismissible: false, style: { margin: '8px 16px' } },
            __('Edit the policy in this sidebar. Values are stored on the block, not as page custom fields.', 'walkridge'),
          ),
          textPanel(
            __('Store', 'walkridge'),
            [
              ['effectiveDate', __('Effective date', 'walkridge'), false],
              ['storeName', __('Store name', 'walkridge'), false],
              ['storeUrl', __('Store URL', 'walkridge'), false],
              ['contactEmail', __('Contact email', 'walkridge'), false],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Windows (days)', 'walkridge'), initialOpen: true },
            el(RangeControl, {
              label: __('Refund window', 'walkridge'),
              value: a.refundWindowDays || 30,
              min: 1,
              max: 90,
              onChange: (v) => s({ refundWindowDays: v }),
            }),
            el(RangeControl, {
              label: __('Bug resolution window', 'walkridge'),
              value: a.resolutionDays || 7,
              min: 1,
              max: 30,
              onChange: (v) => s({ resolutionDays: v }),
            }),
            el(RangeControl, {
              label: __('Duplicate-purchase window', 'walkridge'),
              value: a.duplicateDays || 7,
              min: 1,
              max: 30,
              onChange: (v) => s({ duplicateDays: v }),
            }),
            el(RangeControl, {
              label: __('Response time (business days)', 'walkridge'),
              value: a.responseDays || 2,
              min: 1,
              max: 14,
              onChange: (v) => s({ responseDays: v }),
            }),
            el(RangeControl, {
              label: __('Min refund processing days', 'walkridge'),
              value: a.paymentDaysMin || 5,
              min: 1,
              max: 30,
              onChange: (v) => s({ paymentDaysMin: v }),
            }),
            el(RangeControl, {
              label: __('Max refund processing days', 'walkridge'),
              value: a.paymentDaysMax || 10,
              min: 1,
              max: 45,
              onChange: (v) => s({ paymentDaysMax: v }),
            }),
          ),
        ),
    })
  },
  save: () => null,
})

registerBlockType('walkridge/area-map', {
  title: __('Area Map', 'walkridge'),
  category: 'walkridge',
  icon: 'location-alt',
  description: __('Gettysburg location map with pin, meeting cards, or the Field Map plugin.', 'walkridge'),
  keywords: ['walkridge', 'map', 'area', 'gettysburg', 'location'],
  supports: { html: false },
  attributes: {
    eyebrow: { type: 'string', default: 'Find Us' },
    heading: { type: 'string', default: 'Meeting points & office hours.' },
    text: { type: 'string', default: '' },
    variant: { type: 'string', default: 'static' },
    imageKey: { type: 'string', default: 'downtown' },
    imageUrl: { type: 'string', default: '' },
    imageId: { type: 'number', default: 0 },
    imageAlt: { type: 'string', default: 'Downtown Gettysburg near Lincoln Square' },
    showPin: { type: 'boolean', default: true },
    pinX: { type: 'number', default: 50 },
    pinY: { type: 'number', default: 50 },
    locationMode: { type: 'string', default: 'coordinates' },
    latitude: { type: 'number', default: 39.83092 },
    longitude: { type: 'number', default: -77.23114 },
    zipcode: { type: 'string', default: '17325' },
    mapZoom: { type: 'number', default: 14 },
    mapEmbedUrl: { type: 'string', default: '' },
    mapHeight: { type: 'number', default: 420 },
    layout: { type: 'string', default: 'split' },
    iconTone: { type: 'string', default: 'gold' },
    cards: {
      type: 'string',
      default:
        'Ticket Office & Day Tour Meeting Point | 100 Sample Street, Gettysburg, PA 17325. Concept placeholder — not a live ticket office. Downtown public lots and metered parking sit near Lincoln Square. | pin\nEvening Lantern Walk Meeting Point | Sample downtown meet. Lincoln Square is tour geography, not a live business address. Look for your guide holding a lit lantern. | lantern\nOffice Hours | Mon–Sun, 8:00 AM – 6:00 PM (April–November). Thu–Sun, 9:00 AM – 4:00 PM (December–March). | clock',
    },
  },
  edit({ attributes: a, setAttributes: s }) {
    return el(SsrEdit, {
      name: 'walkridge/area-map',
      attributes: a,
      sidebar: () =>
        el(
          Fragment,
          null,
          textPanel(
            __('Section copy', 'walkridge'),
            [
              ['eyebrow', __('Eyebrow', 'walkridge'), false],
              ['heading', __('Heading', 'walkridge'), false],
              ['text', __('Supporting text', 'walkridge'), true],
            ],
            a,
            s,
          ),
          el(
            PanelBody,
            { title: __('Map type', 'walkridge'), initialOpen: true },
            el(SelectControl, {
              label: __('Display', 'walkridge'),
              value: a.variant || 'static',
              options: [
                { label: __('Static photo + pin (Hallowed Ground)', 'walkridge'), value: 'static' },
                { label: __('Embedded map (OSM / Google iframe URL)', 'walkridge'), value: 'embed' },
                { label: __('Interactive Field Map plugin', 'walkridge'), value: 'field-map' },
              ],
              onChange: (v) => s({ variant: v }),
              help: __('Embed builds OpenStreetMap from Location (coordinates or ZIP). A custom iframe URL overrides that. Field Map needs the Walkridge Field Map plugin.', 'walkridge'),
            }),
            el(RangeControl, {
              label: __('Map height (px)', 'walkridge'),
              value: a.mapHeight || 420,
              min: 240,
              max: 800,
              step: 20,
              onChange: (v) => s({ mapHeight: v }),
            }),
            el(SelectControl, {
              label: __('Layout', 'walkridge'),
              value: a.layout || 'split',
              options: [
                { label: __('Map left, cards right', 'walkridge'), value: 'split' },
                { label: __('Cards left, map right', 'walkridge'), value: 'split-flip' },
                { label: __('Stacked (map above cards)', 'walkridge'), value: 'stack' },
              ],
              onChange: (v) => s({ layout: v }),
            }),
            el(SelectControl, {
              label: __('Icon color', 'walkridge'),
              value: a.iconTone || 'gold',
              options: [
                { label: __('Gold (theme accent)', 'walkridge'), value: 'gold' },
                { label: __('Lantern', 'walkridge'), value: 'lantern' },
                { label: __('Parchment', 'walkridge'), value: 'parchment' },
                { label: __('Brick', 'walkridge'), value: 'brick' },
              ],
              onChange: (v) => s({ iconTone: v }),
              help: __('Uses Walkridge theme tokens so light and dark modes stay in sync.', 'walkridge'),
            }),
          ),
          el(
            PanelBody,
            { title: __('Location', 'walkridge'), initialOpen: true },
            el(SelectControl, {
              label: __('Place the map by', 'walkridge'),
              value: a.locationMode || 'coordinates',
              options: [
                { label: __('Latitude & longitude', 'walkridge'), value: 'coordinates' },
                { label: __('ZIP / postal code', 'walkridge'), value: 'zipcode' },
              ],
              onChange: (v) => s({ locationMode: v }),
              help: __('Used for the OpenStreetMap embed and the “open this location” link. ZIP codes are looked up through OpenStreetMap Nominatim.', 'walkridge'),
            }),
            (a.locationMode || 'coordinates') === 'zipcode'
              ? el(TextControl, {
                  label: __('ZIP / postal code', 'walkridge'),
                  value: a.zipcode || '',
                  onChange: (v) => s({ zipcode: v }),
                  help: __('US 5-digit or other postal codes. Default 17325 (Gettysburg).', 'walkridge'),
                })
              : el(
                  Fragment,
                  null,
                  el(TextControl, {
                    label: __('Latitude', 'walkridge'),
                    type: 'number',
                    value: a.latitude ?? 39.83092,
                    onChange: (v) => s({ latitude: v === '' ? 39.83092 : parseFloat(v) }),
                  }),
                  el(TextControl, {
                    label: __('Longitude', 'walkridge'),
                    type: 'number',
                    value: a.longitude ?? -77.23114,
                    onChange: (v) => s({ longitude: v === '' ? -77.23114 : parseFloat(v) }),
                  }),
                ),
            el(RangeControl, {
              label: __('Zoom (embed)', 'walkridge'),
              value: a.mapZoom || 14,
              min: 8,
              max: 18,
              onChange: (v) => s({ mapZoom: v }),
            }),
          ),
          (a.variant || 'static') === 'static' &&
            el(
              Fragment,
              null,
              el(
                PanelBody,
                { title: __('Map image', 'walkridge'), initialOpen: false },
                el(SelectControl, {
                  label: __('Preset image', 'walkridge'),
                  value: a.imageKey || 'downtown',
                  options: [
                    { label: __('Downtown Gettysburg', 'walkridge'), value: 'downtown' },
                    { label: __('Cannon / field', 'walkridge'), value: 'cannon' },
                    { label: __('Wentz farmstead', 'walkridge'), value: 'wentz' },
                  ],
                  onChange: (v) => s({ imageKey: v }),
                }),
                el(TextControl, {
                  label: __('Image alt text', 'walkridge'),
                  value: a.imageAlt || '',
                  onChange: (v) => s({ imageAlt: v }),
                }),
                el(ToggleControl, {
                  label: __('Show location pin', 'walkridge'),
                  checked: a.showPin !== false,
                  onChange: (v) => s({ showPin: v }),
                }),
                a.showPin !== false &&
                  el(RangeControl, {
                    label: __('Pin left (%)', 'walkridge'),
                    value: a.pinX ?? 50,
                    min: 0,
                    max: 100,
                    onChange: (v) => s({ pinX: v }),
                  }),
                a.showPin !== false &&
                  el(RangeControl, {
                    label: __('Pin top (%)', 'walkridge'),
                    value: a.pinY ?? 50,
                    min: 0,
                    max: 100,
                    onChange: (v) => s({ pinY: v }),
                  }),
              ),
              mediaUploadField(__('Custom map photo', 'walkridge'), 'imageUrl', a, s),
            ),
          (a.variant || 'static') === 'embed' &&
            el(
              PanelBody,
              { title: __('Embed URL', 'walkridge'), initialOpen: true },
              urlField(__('Optional custom iframe URL (overrides coordinates / ZIP)', 'walkridge'), 'mapEmbedUrl', a, s),
            ),
          el(
            PanelBody,
            { title: __('Meeting cards', 'walkridge'), initialOpen: false },
            el(TextareaControl, {
              label: __('Cards (one per line: Title | Text | pin, lantern, or clock)', 'walkridge'),
              value: a.cards || '',
              onChange: (v) => s({ cards: v }),
              rows: 8,
            }),
          ),
        ),
    });
  },
  save: () => null,
});

